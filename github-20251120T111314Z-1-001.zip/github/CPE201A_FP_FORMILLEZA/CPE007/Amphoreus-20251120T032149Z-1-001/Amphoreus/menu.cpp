#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;


void parentMenu(Account &acc) {
    int ch;
    int pending = 0;
    for (int i = 0; i < requestCount; ++i) if (toLowerStr(requests[i].status) == "pending") ++pending;
    if (pending > 0) cout << "You have " << pending << " pending request(s).\n";
    while (true) {
        drawHeaderBox("PARENT MENU");
        cout << "1) Add Budget Record\n2) Show All Budgets\n3) Edit Budget\n4) Delete Budget\n5) Search / Filter\n6) Sort Budgets\n7) Summary Report\n8) View & Process Requests\n9) Manage Profiles\n10) Manage Accounts\n0) Logout\n";
        ch = getIntInput("Choice: ");
        if (ch == 0) break;
        if (ch == 1) addBudgetInteractive(acc.username);
        else if (ch == 2) showAllBudgetsFancy();
        else if (ch == 3) editBudgetInteractive(acc.username, true);
        else if (ch == 4) deleteBudgetInteractive(acc.username, true);
        else if (ch == 5) searchBudgetsMenu();
        else if (ch == 6) sortBudgetsMenu();
        else if (ch == 7) showSummary();
        else if (ch == 8) parentProcessRequests();
        else if (ch == 9) manageProfiles();
        else if (ch == 10) manageAccounts();
        else cout << "Invalid choice.\n";
    }
}

void childMenu(Account &acc) {
    bool isAdult = acc.age >= 18;
    while (true) {
        drawHeaderBox("CHILD MENU");
        cout << "1) Show All Budgets\n2) Request Budget\n3) View My Requests\n";
        if (isAdult) cout << "4) Add Budget (as owner)\n5) Edit My Budgets\n6) Delete My Budgets\n";
        cout << "7) Summary Report\n0) Logout\n";
        int ch = getIntInput("Choice: ");
        if (ch == 0) break;
        if (ch == 1) showAllBudgetsFancy();
        else if (ch == 2) submitRequest(acc);
        else if (ch == 3) {
            bool found = false;
            cout << "+-------------------------------------------+\n";
            cout << "| ID | Purpose                     | Amount |\n";
            cout << "+-------------------------------------------+\n";
            for (int i = 0; i < requestCount; ++i) if (toLowerStr(requests[i].childUsername) == toLowerStr(acc.username)) {
                found = true;
                cout << "| " << setw(3) << requests[i].id << " | " << left << setw(26) << requests[i].purpose << " | " << right << setw(7) << fixed << setprecision(2) << requests[i].amount << " |\n";
            }
            cout << "+-------------------------------------------+\n";
            if (!found) cout << "No requests found.\n";
        } else if (isAdult && ch == 4) addBudgetInteractive(acc.username);
        else if (isAdult && ch == 5) editBudgetInteractive(acc.username, true);
        else if (isAdult && ch == 6) deleteBudgetInteractive(acc.username, true);
        else if (ch == 7) showSummary();
        else cout << "Invalid choice.\n";
    }
}

void bootstrapDefaultsIfEmpty() {
    if (accountCount == 0) {
        Account p; p.username = "parent"; p.password = "parent123"; p.role = "Parent"; p.age = 40;
        accounts[accountCount++] = p;
        Account c; c.username = "child"; c.password = "child123"; c.role = "Child"; c.age = 14;
        accounts[accountCount++] = c;
        saveAccountsToFile();
    }
    if (profileCount == 0) {
        Profile p; p.username = "child"; p.displayName = "Child User"; p.age = 14; p.allowance = 0.0;
        profiles[profileCount++] = p;
        saveProfilesToFile();
    }
}

