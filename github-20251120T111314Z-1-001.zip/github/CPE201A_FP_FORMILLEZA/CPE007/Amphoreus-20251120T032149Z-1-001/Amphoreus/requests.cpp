#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

void parentProcessRequests() {
    if (requestCount == 0) { cout << "No requests.\n"; return; }
    cout << "+------------------------------------------------------------------------------------------------+\n";
    cout << "|  ID | Username         | Child Name         | Purpose                       |    Amount | Status     |\n";
    cout << "+------------------------------------------------------------------------------------------------+\n";
    for (int i = 0; i < requestCount; ++i) {
        cout << "| " << setw(3) << requests[i].id << " | " << left << setw(16) << requests[i].childUsername << " | " << setw(18) << requests[i].childName << " | " << setw(28) << requests[i].purpose << " | " << right << setw(9) << fixed << setprecision(2) << requests[i].amount << " | " << setw(10) << requests[i].status << " |\n";
    }
    cout << "+------------------------------------------------------------------------------------------------+\n";
    int id = getIntInput("Enter request ID to process (0 to cancel): ");
    if (id == 0) return;
    int idx = -1;
    for (int i = 0; i < requestCount; ++i) if (requests[i].id == id) { idx = i; break; }
    if (idx == -1) { cout << "Request not found.\n"; return; }
    if (toLowerStr(requests[idx].status) != "pending") { cout << "Already processed.\n"; return; }
    cout << "1) Approve  2) Reject\n";
    int ch = getIntInput("Choice: ");
    if (ch == 1) {
        requests[idx].status = "Approved";
        if (budgetCount < MAX_BUDGETS) {
            Budget b;
            b.id = nextBudgetId++;
            b.name = "Approved Request - " + requests[idx].childName + " - " + requests[idx].purpose;
            b.amount = requests[idx].amount;
            b.type = "Expense";
            b.owner = "system";
            budgets[budgetCount++] = b;
            saveBudgetsToFile();
            cout << "Request approved and recorded as expense.\n";
        } else cout << "Budget storage full; cannot record expense.\n";
    } else if (ch == 2) {
        requests[idx].status = "Rejected";
        cout << "Request rejected.\n";
    } else cout << "Invalid choice.\n";
    saveRequestsToFile();
}

