#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;


void manageProfiles() {
    cout << "Profile Manager: 1) List  2) Edit Allowance  3) Add  4) Remove  0) Back\n";
    int ch = getIntInput("Choice: ");
    if (ch == 0) return;
    if (ch == 1) {
        if (profileCount == 0) cout << "No profiles.\n";
        else {
            cout << "+-------------------------------------------------------------+\n";
            cout << "| Username       | Display Name             | Age | Allowance |\n";
            cout << "+-------------------------------------------------------------+\n";
            for (int i = 0; i < profileCount; ++i) cout << "| " << setw(14) << profiles[i].username << " | " << setw(24) << profiles[i].displayName << " | " << setw(3) << profiles[i].age << " | " << setw(9) << fixed << setprecision(2) << profiles[i].allowance << " |\n";
            cout << "+-------------------------------------------------------------+\n";
        }
    } else if (ch == 2) {
        string uname = getLineInputNonEmpty("Enter username: ");
        Profile* p = findProfileByUsername(uname);
        if (!p) { cout << "Profile not found.\n"; return; }
        double a = getDoubleInput("Enter new allowance: ");
        p->allowance = a;
        saveProfilesToFile();
        cout << "Allowance updated.\n";
    } else if (ch == 3) {
        if (profileCount >= MAX_PROFILES) { cout << "Profile storage full.\n"; return; }
        Profile p;
        p.username = getLineInputNonEmpty("Enter username (must match account): ");
        bool accExists = false;
        for (int i = 0; i < accountCount; ++i) if (toLowerStr(accounts[i].username) == toLowerStr(p.username)) { accExists = true; break; }
        if (!accExists) { cout << "No account with that username; create account first.\n"; return; }
        p.displayName = getLineInputNonEmpty("Enter display name: ");
        p.age = getIntInput("Enter age: ");
        p.allowance = getDoubleInput("Enter allowance: ");
        profiles[profileCount++] = p;
        saveProfilesToFile();
        cout << "Profile added.\n";
    } else if (ch == 4) {
        string uname = getLineInputNonEmpty("Enter username to remove: ");
        int idx = -1;
        for (int i = 0; i < profileCount; ++i) if (toLowerStr(profiles[i].username) == toLowerStr(uname)) { idx = i; break; }
        if (idx == -1) { cout << "Profile not found.\n"; return; }
        for (int i = idx; i < profileCount - 1; ++i) profiles[i] = profiles[i + 1];
        profileCount--;
        saveProfilesToFile();
        cout << "Profile removed.\n";
    } else cout << "Invalid choice.\n";
}

void manageAccounts() {
    cout << "Account Manager: 1) List  2) Delete  3) Reset Password  0) Back\n";
    int ch = getIntInput("Choice: ");
    if (ch == 0) return;
    if (ch == 1) {
        if (accountCount == 0) cout << "No accounts.\n";
        else {
            cout << "+--------------------------------+\n";
            cout << "| Username       | Role    | Age |\n";
            cout << "+--------------------------------+\n";
            for (int i = 0; i < accountCount; ++i) cout << "| " << setw(14) << accounts[i].username << " | " << setw(7) << accounts[i].role << " | " << setw(3) << accounts[i].age << " |\n";
            cout << "+--------------------------------+\n";
        }
    } else if (ch == 2) {
        string uname = getLineInputNonEmpty("Enter username to delete: ");
        int idx = -1;
        for (int i = 0; i < accountCount; ++i) if (toLowerStr(accounts[i].username) == toLowerStr(uname)) { idx = i; break; }
        if (idx == -1) { cout << "Account not found.\n"; return; }
        for (int i = idx; i < accountCount - 1; ++i) accounts[i] = accounts[i + 1];
        accountCount--;
        saveAccountsToFile();
        cout << "Account deleted.\n";
    } else if (ch == 3) {
        string uname = getLineInputNonEmpty("Enter username to reset password: ");
        int idx = -1;
        for (int i = 0; i < accountCount; ++i) if (toLowerStr(accounts[i].username) == toLowerStr(uname)) { idx = i; break; }
        if (idx == -1) { cout << "Account not found.\n"; return; }
        cout << "Enter new password: ";
        string np; getline(cin, np);
        accounts[idx].password = np;
        saveAccountsToFile();
        cout << "Password reset.\n";
    } else cout << "Invalid choice.\n";
}

