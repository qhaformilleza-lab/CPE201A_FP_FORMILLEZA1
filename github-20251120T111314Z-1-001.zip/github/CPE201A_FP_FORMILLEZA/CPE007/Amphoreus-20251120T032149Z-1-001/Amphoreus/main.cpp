#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include <algorithm>

#include "Funcs.h"
#include "Structs.h"
#include "globals.h"
using namespace std;

Budget budgets[600];
int budgetCount = 0;
int nextBudgetId = 1;

Request requests[200];
int requestCount = 0;
int nextRequestId = 1;

Account accounts[200];
int accountCount = 0;

Profile profiles[200];
int profileCount = 0;

int main() {
	loadAccountsFromFile();
    loadProfilesFromFile();
    loadBudgetsFromFile();
    loadRequestsFromFile();
    bootstrapDefaultsIfEmpty();
    drawHeaderBox("FAMILY BUDGET MANAGER");
    while (true) {
        cout << "\n+------------------------------------------------+\n";
        cout << "| 1) Parent Login                                |\n";
        cout << "| 2) Child Login                                 |\n";
        cout << "| 3) Create Account                              |\n";
        cout << "| 4) Show Summary                                |\n";
        cout << "| 5) Exit                                        |\n";
        cout << "+------------------------------------------------+\n";
        int mainChoice = getIntInput("Enter choice: ");
        if (mainChoice == 5) { cout << "Goodbye.\n"; break; }
        if (mainChoice == 1) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Parent Login\n";
            Account *acc = loginAccount();
            if (acc && toLowerStr(acc->role) == "parent"){
            	 parentMenu(*acc);
			} else cout << "Login failed or not a parent account.\n";
			
        } else if (mainChoice == 2) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Child Login\n";
            Account *acc = loginAccount();
            if (acc && toLowerStr(acc->role) == "child"){
            	childMenu(*acc);
			} else cout << "Login failed or not a child account.\n";
        } else if (mainChoice == 3) {
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            createAccount();
        } else if (mainChoice == 4) {
            showSummary();
        } else cout << "Invalid choice.\n";
    }
    return 0;
}
